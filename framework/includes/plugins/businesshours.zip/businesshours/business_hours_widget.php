<?php
	// Register Widget 
	function aivah_businesshours_widgets() {
		register_widget( 'aivah_businesshours_widgets' );
	}
	// Define the Widget as an extension of WP_Widget
	class aivah_businesshours_widgets extends WP_Widget {
		/* constructor */
		function aivah_businesshours_widgets() {
			global $theme_name;
			/* Widget settings. */
			$widget_ops = array(
				'classname'		=> 'aivah_businesshours_widgets',
				'description'	=> __('Display Business Hours.', 'atp_admin')
			);
			/* Widget control settings. */
			$control_ops = array(
				'width'		=> 300,
				'height'	=> 350,
				'id_base'	=> 'aivah_businesshours_widgets'
			);
			/* Create the widget. */
			$this->WP_Widget( 'aivah_businesshours_widgets','ATP Business Hours', $widget_ops, $control_ops );
		}
			function viewdays(){	
				global $wpdb;						
				$sql = "SELECT * FROM $wpdb->aivah_businessdays" ;
				$found = 0;
				$data = Array();
					if ($results = $wpdb->get_results($sql)) {
						foreach ($results as $value) {
							$found++;
						}
						if($found==0){
							return $data; 
						}else{
							$data = $wpdb->get_results($sql, ARRAY_N); 
							return $data; 
						}
					}
				}

		// outputs the content of the widget
		function viewhours() {	
				global $wpdb;						
				$sql = "SELECT * FROM $wpdb->aivah_businesshours" ;
				$found = 0;
				$data = Array();
				if($results = $wpdb->get_results($sql)) {
						foreach ($results as $value) {
							$found++;
						}
					if($found==0){
						return $data; 
					}else{
						$data = $wpdb->get_results($sql, ARRAY_A); 
						return $data; 
					}
				}
			}
		function widget( $args, $instance ) {
			extract( $args );
			/* Our variables from the widget settings. */
			$businesshours_title = $instance['businesshours_title'];
			$closed_text = $instance['closed_text'];
				$group_days=$instance['group_days'];
			$before_title	='<h3 class="widget-title">';
			$after_title	='</h3>';
			$before_widget	='<div id="businesshours" class="widget businesshours">';
			$after_widget	='</div>';
			/* Before widget (defined by themes). */
			echo $before_widget;
			/* Title of widget (before and after defined by themes). */
			if($businesshours_title !=='') {
			echo $before_title.$businesshours_title.$after_title;
			}
			$out ='';//stores the output
			$businesshours_stored =$this->viewhours();
			$values=$businesshours_stored['0'];
			$i =0; 
			$arr_weekdays = array('sunday','monday','tuesday','wednesday','thursday','friday','saturday');
				$arrweekdayslabels =$this->viewdays(); 
				$arrweekdays=$arrweekdayslabels['0']; 
				$arrweekdays_shift=array_shift($arrweekdays);
				foreach ($arr_weekdays as $value){
					//print_r($values[$week_days[$i]]);
					$time_hours=explode('-',$values[$arr_weekdays[$i]]);
					// 24 hours format
					if($values['timeformat'] =='24'){
						if($time_hours['2']=='on') {
							$arr[$i]='<span>'.$closed_text.'</span>'; 
						}else{
							$arr[$i]=$time_hours['0'].' - '.$time_hours['1'];
						}
					}

					// 12 hours format
					if($values['timeformat']=='12'){
						if($time_hours['2']=='on') {
							$arr[$i]='<span>'.$closed_text.'</span>'; 
						}else{
							 $day_hours['opening'] = $time_hours['0'].':'.'00';
							 $day_hours['closing'] = $time_hours['1'].':'.'00';
							$arr[$i]=date("g:i A", strtotime($day_hours['opening'])).' - '.date("g:i A", strtotime($day_hours['closing']));
						}
					}
					// Weeks Array Indexing
					$i++;
				}
				// Temporary Stores the Values
				if($group_days==="true") {
				$tmp_arr = array();
				$tmp_arr = $arr;
				for($i=1;$i<=6;$i++) {
					if($arr[$i] != $arr[$i-1]) {
						$tmp_arr[$i]=$arr[$i];
					} else {
						unset($tmp_arr[$i]);
					}
				}
				$prev_key =0;
				foreach($tmp_arr as $key => $val) { 
					if(!isset($tmp_arr[$key+1]) && $key<6){
						echo '<p><span class="days">'.$arrweekdays[$key].' - ';
						if(key($tmp_arr)!=''){
							$next_key = key($tmp_arr);
							echo $arrweekdays[$next_key-1].' </span><span class="hours">'.$tmp_arr[$key].'</span></p>';
						} else {
							echo  $arrweekdays[6].' </span><span class="hours">'.$tmp_arr[$key].'</span></p>';
						}
					//prev($tmp_arr);
					} else {
						echo '<p><span class="days">'.$arrweekdays[$key].' </span><span class="hours">'.$val.'</p>';
					}
			next($tmp_arr);
		}
		}else{
			// With Out Grouping Days
			for($number=0;$number<=6; $number++)
		{
		echo '<p><span class="days">'.$arrweekdays[$number].'</span><span class="hours">'.$arr[$number].'</span></p>';
	
		}
		}
			echo $out;
			/* After widget (defined by themes). */
			echo $after_widget;
		}

		//processes widget options to be saved

		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
			/* Strip tags for title and name to remove HTML (important for text inputs). */
			$instance['businesshours_title'] = strip_tags( $new_instance['businesshours_title'] );
			$instance['group_days'] = strip_tags( $new_instance['group_days'] );
			$instance['closed_text'] = strip_tags( $new_instance['closed_text'] );
			return $instance;
		}
		// outputs the options form on admin
		function form( $instance ) {
			/* Set up some default widget settings. */
			$instance = wp_parse_args( (array) $instance, array( 
				'businesshours_title' => '',
				'closed_text' => 'Closed',
				'group_days'=>'')  
			);
			$closed_text = strip_tags($instance['closed_text']);
			$businesshours_title = strip_tags($instance['businesshours_title']);?>
			<p>
				<label for="<?php echo $this->get_field_id( 'businesshours_title' ); ?>"><?php _e('Title:', 'atp_businesshours'); ?></label>
				<input id="<?php echo $this->get_field_id( 'businesshours_title' ); ?>" name="<?php echo $this->get_field_name( 'businesshours_title' ); ?>" value="<?php echo $businesshours_title; ?>" type="text" style="width:100%;" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'closed_text' ); ?>"><?php _e('Closed Text:', 'atp_businesshours'); ?></label>
				<input id="<?php echo $this->get_field_id( 'closed_text' ); ?>" name="<?php echo $this->get_field_name( 'closed_text' ); ?>" value="<?php echo $closed_text; ?>" type="text" style="width:100%;" />
			</p>
			<p>
			<input type="checkbox" value="true" id="<?php echo $this->get_field_id( 'group_days' ); ?>" name="<?php echo $this->get_field_name( 'group_days' ); ?>" <?php  if( $instance['group_days']=="true") { echo "checked"; } ?> class="checkbox" /> <label for="<?php echo $this->get_field_id( 'group_days' ); ?>"><?php _e('Check this if you wish to group the days, if time for the days are same.?', 'atp_admin'); ?></label>		</p>
		<?php 
		} 
	}
	/* Add our function to the widgets_init hook. */
	add_action( 'widgets_init', 'aivah_businesshours_widgets' );
 ?>