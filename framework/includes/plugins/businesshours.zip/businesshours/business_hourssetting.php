<?php
	if(isset($_POST) && isset($_POST['hourssetting'])=='hourssetting'){
		echo hourssetting_plus_actions($_POST);   
	}
	// save timeings
	function hourssetting_plus_actions($post){
		global $wpdb;
		$sunday_hours=$_POST['aivah_sunday_opening'].'-' .$_POST['aivah_sunday_closing'].'-'.dayclose('aivah_sunday_close');
		$monday_hours=$_POST['aivah_monday_opening'].'-' .$_POST['aivah_monday_closing'].'-'.dayclose('aivah_monday_close');
		$tuesday_hours=$_POST['aivah_tuesday_opening'].'-' .$_POST['aivah_tuesday_closing'].'-'.dayclose('aivah_tuesday_close');
		$wednes_hours=$_POST['aivah_wednesday_opening'].'-' .$_POST['aivah_wednesday_closing'].'-'.dayclose('aivah_wednesday_close');
		$thursday_hours=$_POST['aivah_thursday_opening'].'-' .$_POST['aivah_thursday_closing'].'-'.dayclose('aivah_thursday_close');
		$friday_hours=$_POST['aivah_friday_opening'].'-' .$_POST['aivah_friday_closing'].'-'.dayclose('aivah_friday_close');
		 $saturday_hours=$_POST['aivah_saturday_opening'].'-' .$_POST['aivah_saturday_closing'].'-'.dayclose('aivah_saturday_close');
		$timeformat=$_POST['aivah_timeformat'];
		$wpdb->query("UPDATE $wpdb->aivah_businesshours SET  sunday='$sunday_hours',monday='$monday_hours',tuesday='$tuesday_hours',wednesday='$wednes_hours',thursday='$thursday_hours',friday='$friday_hours',saturday='$saturday_hours',timeformat='$timeformat' WHERE id='1'");
			echo '<div class="updated"><p><strong>Business Hours Setup</strong></p></div>';
	}		function dayclose($day)		{		$new_value = isset($_POST[$day])?$_POST[$day]:'';		$new_value !=''? 'on':'off';			return $new_value;		}
	/*
	 * Hours variables
	 * string Name
	 * string desc
	 * int id
	 * str business hours
	 * str desc
	 */
	$shortname='aivah';
	$business_hours= array();	$array_days = array('sunday','monday','tuesday','wednesday','thursday','friday','saturday');	for($i=0;$i<=6;$i++){			array_push($business_hours, array(			'name'	=> $array_days[$i],			'id'	=> $shortname.'_'.$array_days[$i],						'desc'	=> '',						'std'	=> array(									'opening'	=> '09:00',									'closing'	=> '18:30',									'close' 	=> 'off'),									));	   	}
	function viewhours(){	
		global $wpdb;						
		$sql = "SELECT * FROM $wpdb->aivah_businesshours" ;
			$found = 0;
			$data = Array();
			if ($results = $wpdb->get_results($sql)) {
				foreach ($results as $value) {
					$found++;
				}
				if($found==0){
					return $data; 
				}else{
					$data = $wpdb->get_results($sql, ARRAY_A); 
					return $data; 
				}
			}
		}
		echo " <h2>" . __('Update Business Setup', 'aivah_busineshours') . "</h2>"; 
		echo __('Setup timings for the weekdays of your business hours.', 'aivah_businesshours');
		$output='<form method="post" action="">
			<table class="form-table">
			<tbody>	'; 						
		//$alldata = viewhours();
		$businesshours_stored =viewhours();     	
		foreach ($business_hours as $value){
			$output.='<tr valign="top">
                <th scope="row"><label for="name">'.ucfirst($value['name']).'</label>
                </th><td>';               
			$default = $value['std'];
			$values=$businesshours_stored['0'];
				//var_dump($values);
				$values1=explode('-',$values[strtolower($value['name'])]);
			$val = $value['std']['opening'];
				if ( $value['std']['opening'] != "") { $val = $values1['0']; }
					$output .= '<label>Opening </label><select class="atp-businesshours atp-businesshours-openingtime" name="'. $value['id'].'_opening" id="'. $value['id'].'_opening">';
				for ($i = 0; $i < 24; $i++){ 
						$h = $i;
						if ( $h < 10) { $h = '0' . $h; }
						for($m=0;$m<=45;$m+=15) {
							if($m == 0) $m .='0';
							$hours = $h.':'.$m;						
							if($val === $hours){
								$active = 'selected="selected"'; 
							} else { 
								$active = ''; 
							}
							$output .= '<option value="'. $h .':'.$m.'" ' . $active . '>'. $h .':'.$m.'</option>'; 
						}
					}
					$output .= '</select>';
				// Closing
				$val = $value['std']['closing'];
				if ( $value['std']['closing'] != "") { $val = $values1['1']; }
					$output .= '<label>Closing </label><select class="atp-businesshours atp-businesshours-closingtime" name="'. $value['id'].'_closing" id="'. $value['id'].'_closing">';
				for ($i = 0; $i < 24; $i++){ 
						$h = $i;
						if ( $h < 10) { $h = '0' . $h; }
						for($m=0;$m<=45;$m+=15) {
							if($m == 0) $m .='0';							$hours = $h.':'.$m;							
							if($val === $hours){								$active = 'selected="selected"'; 
							} else { 
								$active = ''; 
							}
							$output .= '<option value="'. $h .':'.$m.'" ' . $active . '>'. $h .':'.$m.'</option>'; 
						}
					}
					$output .= '</select>';
				// Closed
				$val = $value['std']['close'];
				if ( $value['std']['close'] != "") { $val = $values1['2']; }
					$checked='';
					if(!empty($val)) {
					if($val == 'on') {
						$checked = 'checked="checked"';
					}else{
						$checked = '';
					}
				}
			$output .= '<label>Closed </label><input '. $checked .' type="checkbox" class="checkbox atp-input " value="on" name="'. $value['id'].'_close" id="'. $value['id'].'_close">';
			$output .= '<label class="time_error" id="'. $value['id'].'_error"></label>';
			$output .='</td></tr>';
		}
		$selectedOption=$values['timeformat'];
		$options['0']='';
		$options['1']='';
		if($selectedOption == '12'){
			$options['0'] = "selected='selected'";
		}
		if($selectedOption == '24'){
			$options['1'] = "selected='selected'";
		}
		$output.='<tr valign="top">
				<th scope="row"><label for="name">Time Format</label>
				</th>';
		$output .='<td>';
		$output .='<select id="aivah_timeformat" name="aivah_timeformat">';
		$output .='<option value="12" '.$options['0'].' >12</option>';
		$output .='<option value="24" '.$options['1'].' >24</option>';
		$output .='</select></td></tr>';
		$output.='</tbody></table>';
		$output.='<input type="hidden" value="hourssetting" name="hourssetting"/><input type="submit" value="Save" class="button-primary" name="Submit"/>';
		$output.='</form>';
		echo $output;
?>