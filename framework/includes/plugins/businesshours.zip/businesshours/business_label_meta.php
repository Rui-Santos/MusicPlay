<?php
	if(isset($_POST) && isset($_POST['daysetting'])=='daysetting'){
		echo daysetting_plus_actions($_POST);
	}
	// Save Week Days Label
	function daysetting_plus_actions($post){
		global $wpdb;
		$sunday		= $_POST['label_sunday'];
		$monday		= $_POST['label_monday'];
		$tuesday	= $_POST['label_tuesday'];
		$wednesday	= $_POST['label_wednesday'];
		$thursday	= $_POST['label_thursday'];
		$friday		= $_POST['label_friday'];
		$saturday	= $_POST['label_saturday'];
		
		$wpdb->query("UPDATE $wpdb->aivah_businessdays SET labelsunday='$sunday', labelmonday='$monday', labeltuesday='$tuesday', labelwednesday='$wednesday', labelthursday='$thursday', labelfriday='$friday',labelsaturday='$saturday' WHERE id='1'");
		echo '<div id="message" class="updated fade"><p><strong>Business Days Updated..</strong></p></div>';
	}


	// Retrieve the Labels from DB
	function viewdays() {
		global $wpdb;

		$sql = "SELECT * FROM $wpdb->aivah_businessdays" ;
		$found = 0;
		$data = Array();

		if ($results = $wpdb->get_results($sql)) {

			foreach ($results as $value) {
				$found++;
			}

			if($found==0){
				return $data; 
			}else{
				$data = $wpdb->get_results($sql, ARRAY_A); 
				return $data; 
			}
	   }
	}
	?>
<div class="wrap">
	<?php
	$output = '<form method="post" action="">
	<table class="widefat" width="500">
	<thead><tr><th colspan="2">Week Days Labels</th></tr></thead>
	<tbody>';
	$businesdays_stored = viewdays(); 
	for ($i=0;$i<count($businesdays_stored);$i++) {
		$data = $businesdays_stored[$i];
		$output .= '<tr valign="top"><td><label for="name">Sunday</label></td>';
		$output .= '<td><input type="text" class="regular-text" name="label_sunday" id="label_sunday" value="'.$data['labelsunday'].'"></td></tr>';
		$output .= '<tr><td><label for="name">Monday</label></td>';
		$output .= '<td><input type="text" class="regular-text" name="label_monday" id="label_monday" value="'.$data['labelmonday'].'"></td></tr>';
		$output .= '<tr><td><label for="name">Tuesday</label></td>';
		$output .= '<td><input type="text" class="regular-text" name="label_tuesday" id="label_tuesday" value="'.$data['labeltuesday'].'"></td></tr>';
		$output .= '<tr><td><label for="name">Wednesday</label></td>';
		$output .= '<td><input type="text" class="regular-text" name="label_wednesday" id="label_wednesday" value="'.$data['labelwednesday'].'"></td></tr>';
		$output .= '<tr><td><label for="name">Thursday</label></td>';
		$output .= '<td><input type="text" class="regular-text" name="label_thursday" id="label_thursday" value="'.$data['labelthursday'].'"></td></tr>';
		$output .= '<tr><td><label for="name">Friday</label></td>';
		$output .= '<td><input type="text" class="regular-text" name="label_friday" id="label_friday" value="'.$data['labelfriday'].'"></td></tr>';
		$output .= '<tr><td><label for="name">Saturday</label></td>';
		$output .= '<td><input type="text" class="regular-text" name="label_saturday" id="label_saturday" value="'.$data['labelsaturday'].'"></td></tr>';					
	}
	$output .= '</tbody></table>';
	$output .= '<p><input type="hidden" value="daysetting" name="daysetting"/><p><input type="submit" value="Save Changes" class="button button-primary button-large" name="Submit"/></p>';
	$output.='</form>';

	echo $output;
	echo '</div>';


?>