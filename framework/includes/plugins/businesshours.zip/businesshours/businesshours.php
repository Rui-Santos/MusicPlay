<?php
/** 
 * Plugin Name: Aivah Business Hours 
 * Plugin URI: http://www.aivahthemes.com 
 * Description: Displays business hours of your company or office. Useful for Office, Stores, Hotels, Restaurants etc. 
 * Version: 2.0 
 * Author: AivahThemes
 * Author URI: http://www.aivahthemes.com 
 * License: GPL
 * This plugin and its accompanying tutorial are written for Nettuts+ at http://net.tutsplus.com 
 */ 
	global $wpdb;
	
	$wpdb->aivah_businesshours = $table_prefix.'aivah_businesshours';
	$wpdb->aivah_businessdays = $table_prefix.'aivah_businessdays';
	
	add_action('init', 'wp_businesshours_install');

	// action function for above hook
	function wp_businesshours_install() {

		global $wpdb;

		$charset_collate = '';

		if ( ! empty($wpdb->charset) ) {
			$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
		}

		if ( ! empty($wpdb->collate) ) {
			$charset_collate .= " COLLATE $wpdb->collate";
		}

		if ($wpdb->get_var("SHOW TABLES LIKE '$wpdb->aivah_businesshours'") != $wpdb->aivah_businesshours){
			$sql = "CREATE TABLE " . $wpdb->aivah_businesshours . " (
				id int(10) NOT NULL AUTO_INCREMENT,   
				sunday text NOT NULL,
				monday text NOT NULL,
				tuesday text NOT NULL,
				wednesday text NOT NULL,
				thursday text NOT NULL,
				friday text NOT NULL,
				saturday text NOT NULL,
				timeformat varchar(255) NULL,
				PRIMARY KEY (id),  
				KEY id (id)
			)$charset_collate;";
			$wpdb->query($sql);
			$wpdb->query("INSERT INTO $wpdb->aivah_businesshours (sunday,monday,tuesday,wednesday,thursday,friday,saturday,timeformat) VALUES ('10:00-20:00-on','09:00-18:00-off','09:30-19:00-off','09:00-20:00-off','09:00-21:00-off','09:00-22:00-off','09:00-23:00-off','12')");
		}
		
		if ($wpdb->get_var("SHOW TABLES LIKE '$wpdb->aivah_businessdays'") != $wpdb->aivah_businessdays){
			$labelsql = "CREATE TABLE " . $wpdb->aivah_businessdays . " (  
				id int(10) NOT NULL AUTO_INCREMENT,   
				labelsunday text NOT NULL,
				labelmonday text NOT NULL,
				labeltuesday text NOT NULL,
				labelwednesday text NOT NULL,
				labelthursday text NOT NULL,
				labelfriday text NOT NULL,
				labelsaturday text NOT NULL,
				PRIMARY KEY (id),  
				KEY id (id)
			)$charset_collate";
			$wpdb->query($labelsql);
			$wpdb->query("INSERT INTO $wpdb->aivah_businessdays (labelsunday,labelmonday,labeltuesday,labelwednesday,labelthursday,labelfriday,labelsaturday) VALUES ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')");	
		}
	}

	register_uninstall_hook( __FILE__, 'wp_businesshours_uninstall');

	function wp_businesshours_uninstall() {
		
		global $wpdb;
		
		// first remove all tables
		$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}aivah_businessdays");
		$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}aivah_businesshours");
	}

	function business_enqueue_styles(){
		wp_enqueue_style('wp-business', plugins_url('businesshours/business-hours.css'), false, '1.0', 'screen');
	}
	
	add_action('wp_print_styles', 'business_enqueue_styles');
	add_action( 'admin_menu', 'ilc_settings_page_init' );
	
	function ilc_settings_page_init() {
		$settings_page = add_object_page('Business Hours Settings', 'Business Hours', 'edit_theme_options', 'theme-settings', 'business_settings_page' );
	}

	function business_admin_tabs( $current = 'labels' ) { 
		$tabs = array(
			'labels'		=> 'Labels',
			'settings'		=> 'Settings',
			'documentation'	=> 'Documentation' 
		); 
		
		$links = array();
		
		echo '<div id="icon-themes" class="icon32"><br></div>';
		echo '<h2 class="nav-tab-wrapper">';
		
		foreach( $tabs as $tab => $name ){
			$class = ( $tab == $current ) ? ' nav-tab-active' : '';
			echo "<a class='nav-tab$class' href='?page=theme-settings&tab=$tab'>$name</a>";
		}
		
		echo '</h2>';
	}
	
	function business_settings_page() {
		global $pagenow;
		
		echo '<div class="wrap">';
		
		if ( isset ( $_GET['updated'] ) ) {
			if ( 'true' == esc_attr( isset($_GET['updated']) ) ) echo '<div class="updated" ><p>Theme Settings updated.</p></div>';
		}
		
		if ( isset ( $_GET['tab'] ) ) business_admin_tabs($_GET['tab']); else business_admin_tabs('homepage');
			echo '<div id="poststuff">';
			if ( $_GET['page'] == 'theme-settings' ){
			
				if ( isset ( $_GET['tab'] ) ) {
					$tab = $_GET['tab'];
				} else {
					$tab = 'labels'; 
				}

				switch ( $tab ){
					case 'settings' :
							include_once( 'business_hourssetting.php' );
							break;
					case 'labels' :
							include_once( 'business_label_meta.php' );
							break;
					case 'documentation' :
							include_once( 'business_manual.php' );
							break;
				}
			}
		echo'</div>';
		echo'</div>';
	}
	require_once ('business_hours_widget.php'); // business hours widget
	require_once ('business_hours_shortcode.php'); // business hours shortcode