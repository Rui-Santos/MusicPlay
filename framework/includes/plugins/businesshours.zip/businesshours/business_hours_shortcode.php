<?php
	function aivah_businesshours_shortcode ($atts, $content = null) {
		extract(shortcode_atts(array(
			'title'		=> 'Business Hours',
			'width'		=> '600',
			'style'		=> '',
			'grouping'		=> 'true',
			'closetext'		=> 'Closed',
			'class'		=> '',
		), $atts));
		$out ='';//stores the output
		/* Before */
		$out.='<div id="businesshours" class="'.$class.' businesshours" style="width:'.$width.'px">';
		/* Title */
		$out.='<h3 class="widget-title">'.$title.'</h3><div style="'.$style.'">';
		function shortcodeviewhours(){	
			global $wpdb;						
			$sql = "SELECT * FROM $wpdb->aivah_businesshours" ;
			$found = 0;
			$data = Array();
			if ($results = $wpdb->get_results($sql)) {
				foreach ($results as $value) {
					$found++;
				}
				if($found==0){

					return $data; 
				}else{
					$data = $wpdb->get_results($sql, ARRAY_A); 
					return $data; 

				}
			}
		}  
		$businesshours_stored =shortcodeviewhours(); 
		$values=$businesshours_stored['0'];
		$i =0; 
		$arr_weekdays = array('sunday','monday','tuesday','wednesday','thursday','friday','saturday');
		function shortcode_viewdays(){	
			global $wpdb;						
			$sql = "SELECT * FROM $wpdb->aivah_businessdays" ;
			$found = 0;
			$data = Array();
			if ($results = $wpdb->get_results($sql)) {
				foreach ($results as $value) {
					$found++;
				}
				if($found==0){
					return $data; 
				}else{
					$data = $wpdb->get_results($sql, ARRAY_N); 
					return $data; 
				}

		   }

		}
		$arrweekdayslabels =shortcode_viewdays(); 
		$arrweekdays=$arrweekdayslabels['0']; 
		$arrweekdays_shift=array_shift($arrweekdays);
		foreach ($arr_weekdays as $value){
			//print_r($values[$week_days[$i]]);
			$time_hours=explode('-',$values[$arr_weekdays[$i]]);
			// 24 hours format
			if($values['timeformat'] =='24'){
				if($time_hours['2']=='on') {
					$arr[$i]='<span>'.$closetext.'</span>'; 
				}else{
					$arr[$i]=$time_hours['0'].'-'.$time_hours['1'];
				}

			}
			// 12 hours format
			if($values['timeformat']=='12'){
				if($time_hours['2']=='on') {
					$arr[$i]='<span>'.$closetext.'</span>'; 
				}else{
					$day_hours['opening'] = $time_hours['0'].':'.'00';
							 $day_hours['closing'] = $time_hours['1'].':'.'00';
							$arr[$i]=date("g:i A", strtotime($day_hours['opening'])).' - '.date("g:i A", strtotime($day_hours['closing']));
				}

			}
			// Array Indexing for weekdays
			$i++;
		}
		// Temporary Stores Values		
		if($grouping==="true") {
		$tmp_arr = array();
		$tmp_arr = $arr;
		for($i=1;$i<=6;$i++) {
			if($arr[$i] != $arr[$i-1]) {
				$tmp_arr[$i]=$arr[$i];
			} else {
				unset($tmp_arr[$i]);
			}

		}
		$prev_key =0;
		foreach($tmp_arr as $key => $val) {
			if(!isset($tmp_arr[$key+1]) && $key<6){
				$out.='<p><span class="days">'.ucfirst($arrweekdays[$key]).'-';
				if(key($tmp_arr)!=''){
					$next_key = key($tmp_arr);
					$out.=ucfirst($arrweekdays[$next_key-1]).'</span><span class="hours">'.$tmp_arr[$key].'</span></p>';
				} else {
					$out.=ucfirst($arrweekdays[6]).'</span><span class="hours">'.$tmp_arr[$key].'</span></p>';
				}
			//prev($tmp_arr);
			} else {
				$out.='<p><span class="days">'.ucfirst($arrweekdays[$key]).'</span><span class="hours">'.$val.'</p>';
			}
				next($tmp_arr);
		}
		}else{
			for($number=0;$number<=6; $number++)
		{
		$out.='<p><span class="days">'.$arr_weekdays[$number].'</span><span class="hours">'.$arr[$number].'</span></p>';
	
		}
		}
		$out.='</div><div class="clear"></div></div>';
		return $out;
	}
	/* Add our function to the widgets_init hook. */
	add_shortcode( 'businesshours', 'aivah_businesshours_shortcode' );
 ?>