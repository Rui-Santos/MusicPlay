<?php
echo " <h2>" . __('Business Hours Plugin Help', 'aivah_busineshours') . "</h2>"; 
echo "<p>" . __('This section describes how to install the plugin and get it working', 'aivah_busineshours') . "</p>"; 
echo "<ol>";
echo "<li>" . __('Upload `businesshours` directory to the `/wp-content/plugins/` directory', 'aivah_busineshours') . "</li>"; 
echo "<li>" . __('Activate the plugin through the "Plugins" menu in WordPress directory', 'aivah_busineshours') . "</li>";
echo "<li>" . __('Activate the plugin through the "Plugins" menu in WordPress', 'aivah_busineshours') . "</li>";
echo "<li>" . __('Add shortcodes in your posts (e.g: [businesshours title="Office Timings" closetext="closed" grouping="true" width="300" style=""])', 'aivah_busineshours') . "</li>";
echo "<li>" . __('Add your own style internal css (e.g: [businesshours title="Office Timings" closetext="closed" grouping="true" width="300" style="background:#f1f2f3; border:1px solid #ddd; font-size:11px;"])', 'aivah_busineshours') . "</li>";
echo "<li>" . __('Add Your widger in your Widger Area', 'aivah_busineshours') . "</li>";
echo "<li>" . __('Change displaying time format from 12 hrs to 24 hrs from Settings section in admin area', 'aivah_busineshours') . "</li>";
echo "<li>" . __('Change in the layout and styling your business hours display edit business-hours.css file located in the plugins directory', 'aivah_busineshours') . "</li>";
echo "</ol>";
?>